package main

import (
	"flag"
	"fmt"
	"html/template"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"path/filepath"
)

var (
	port         string
	contentDir   string
	sectionFiles []SectionFile
	sections     []Section
	t            *template.Template
)

func init() {
	flag.StringVar(&port, "port", ":8000", "The colon-prefixed port on which to run the server")
	flag.StringVar(&contentDir, "content directory", "content", "The directory that contains all of the individual sections.")

	sectionFiles = []SectionFile{
		{
			Name:     "Discrete Mathematics",
			FilePath: "discrete.html",
		}, {
			Name:     "Imperative vs. Declarative Languages",
			FilePath: "imperative_v_declarative.html",
		}, {
			Name:     "Memory",
			FilePath: "memory.html",
		}, {
			Name:     "Functions",
			FilePath: "functions.html",
		}, {
			Name:     "Variables",
			FilePath: "variables.html",
		}, {
			Name:     "Operators",
			FilePath: "operators.html",
		},
	}
	collectFiles()
}

func main() {
	http.HandleFunc("/", buildIndex)
	http.HandleFunc("/index.css", styles)
	http.HandleFunc("/roadmap", roadmap)
	log.Fatal(http.ListenAndServe(port, nil))
}

// SectionFile represents the Path to a section's file
type SectionFile struct {
	Name     string
	FilePath string
}

// Section is cool
type Section struct {
	Name string
	Body template.HTML
}

func styles(w http.ResponseWriter, r *http.Request) {
	http.ServeFile(w, r, "index.css")
}

func roadmap(w http.ResponseWriter, r *http.Request) {
	http.ServeFile(w, r, "roadmap.html")
}

func buildIndex(w http.ResponseWriter, r *http.Request) {
	t := template.Must(template.New("table_of_contents").Parse(templateStr))
	err := t.Execute(w, sections)
	if err != nil {
		fmt.Println(err)
	}
}

func collectFiles() {
	wd, _ := os.Getwd()
	snippetsDir := filepath.Join(wd, contentDir)

	sections = make([]Section, len(sectionFiles))
	for i, sectionFile := range sectionFiles {
		fullPath := filepath.Join(snippetsDir, sectionFile.FilePath)
		body, _ := ioutil.ReadFile(fullPath)
		sections[i] = Section{
			Name: sectionFile.Name,
			Body: template.HTML(string(body)),
		}
	}
}

// Need to build a table of contents.
// Create a directory that contains all of the content.
// Then create a map of (file names) to (section names) in that directory that you want to serve.
const templateStr = `
<html>
<head>
	<title>Technonomicon</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/foundation/5.5.2/css/foundation.css">
	<link rel="stylesheet" href="index.css">

	<script type="text/x-mathjax-config">
		MathJax.Hub.Config({tex2jax: {inlineMath: [['$','$'], ['\\(','\\)']]}});
	</script>
	<script src='https://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-AMS-MML_HTMLorMML'></script>
<head>

    <body>

    <header>
        <h1>Technonomicon</h1>
        <p>The Compendium Programatica: this is the sum total of my knowledge in Computer Science.</p>
    </header>

    <section>
        <h2>Table of Contents</h2>
        <ol>
            {{ range . }}
            <li><a href="#{{.Name}}">{{ .Name }}</a></li>
            {{ end }}
        </ol>
    </section>
    <article>
        {{ range . }}
        <h2 id="{{ .Name }}">{{ .Name }}</h1>
        <div>
            {{ .Body }}
        </div>
        {{ end }}
    </artctle>
	</body>
</html>
`
